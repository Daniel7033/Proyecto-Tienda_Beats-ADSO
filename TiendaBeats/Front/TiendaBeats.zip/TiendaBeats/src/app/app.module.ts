import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";
import { HttpClient, provideHttpClient, withFetch } from "@angular/common/http";

import { AppComponent } from "./app.component";
import { ModuloSsComponent } from "./pages/modulo-ss/modulo-ss.component";
import { AppRoutingModule } from "./app-routing.module";

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        HttpClient
    ],
    providers: [
        provideHttpClient(withFetch())
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }