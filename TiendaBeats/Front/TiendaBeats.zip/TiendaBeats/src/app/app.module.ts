import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from "./app.routes";
import { AppComponent } from "./app.component";
import { ModuloSsComponent } from "./pages/modulo-ss/modulo-ss.component";

@NgModule({
    declarations: [
        AppComponent,
        ModuloSsComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        HttpClientModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})

export class AppModule { }