import { RouterModule, Routes } from '@angular/router';
import { PersonComponent } from './pages/person/person.component';
import { MenuComponent } from './pages/menu/menu.component';
import { HomeComponent } from './pages/home/home.component';
import { RegistroComponent } from './pages/registro/registro.component';
import { AppComponent } from './app.component';
import { FormUsuarioComponent } from './pages/form-usuario/form-usuario.component';
import { ModuloSsComponent } from './pages/modulo-ss/modulo-ss.component';
import { NgModule } from '@angular/core';

export const routes: Routes = [
    {
        path: '',
        component: HomeComponent
    },
    {
        path: "person",
        component: PersonComponent
    },
    {
        path:"person/registro/:id",
        component: RegistroComponent
    },
    {
        path:'formUsuario',
        component: FormUsuarioComponent
    },
    {
        path: "menu",
        component: MenuComponent
    },
    {
        path:"menu/registro/:id",
        component: RegistroComponent
    },
    {
        path:"modulo-ss",
        component: ModuloSsComponent
    },
    {
        path:'**',
        redirectTo:'',
        pathMatch:'full'
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule{ }