import { RouterModule, Routes } from '@angular/router';
import { PersonComponent } from './pages/person/person.component';
import { MenuComponent } from './pages/menu/menu.component';
import { HomeComponent } from './pages/home/home.component';
import { RegistroComponent } from './pages/registro/registro.component';
import { FormUsuarioComponent } from './pages/form-usuario/form-usuario.component';
import { ModuloSsComponent } from './pages/modulo-ss/modulo-ss.component';
import { NgModule } from '@angular/core';

export const routes: Routes = [
    { path: 'modules', component: ModuloSsComponent },
    { path: 'add-modulo', component: ModuloSsComponent },
    { path: 'edit-modulo/:id', component: ModuloSsComponent },
    {
        path: '',
        component: HomeComponent
    },
    {
        path: "person",
        component: PersonComponent
    },
    {
        path:"person/registro/:id",
        component: RegistroComponent
    },
    {
        path:'formUsuario',
        component: FormUsuarioComponent
    },
    {
        path: "menu",
        component: MenuComponent
    },
    {
        path:"menu/registro/:id",
        component: RegistroComponent
    },
    {
        path:"modulo-ss",
        component: ModuloSsComponent
    },
    {
        path:'**',
        redirectTo:'',
        pathMatch:'full'
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule {}
