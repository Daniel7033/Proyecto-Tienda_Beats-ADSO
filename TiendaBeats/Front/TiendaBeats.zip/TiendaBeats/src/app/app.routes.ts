import { RouterModule, Routes } from '@angular/router';
import { PersonComponent } from './pages/person/person.component';
import { MenuComponent } from './pages/menu/menu.component';
import { HomeComponent } from './pages/home/home.component';
import { RegistroComponent } from './pages/registro/registro.component';
import { FormUsuarioComponent } from './pages/form-usuario/form-usuario.component';
import { ModuloSsComponent } from './pages/Seguridad/modulo-ss/modulo-ss.component'; 
import { NgModule } from '@angular/core';
import { LoginComponent } from './pages/login/login.component';
import { RolSsComponent } from './pages/Seguridad/rol-ss/rol-ss.component';
import { VistaSsComponent } from './pages/Seguridad/vista-ss/vista-ss.component';

export const routes: Routes = [
    //Componentes CRUD SERVICE SECURITY
    //Entity: Modulo
    { path: 'modules', component: ModuloSsComponent },
    { path: 'add-modulo', component: ModuloSsComponent },
    { path: 'edit-modulo/:id', component: ModuloSsComponent },
    //Entity: Usuario
    //Entity: Rol
    { path: 'roles', component: RolSsComponent},
    { path: 'add-rol', component: RolSsComponent },
    { path: 'edit-rol/:id', component: RolSsComponent },
    //Entity: Vista
    { path: 'vistas', component: VistaSsComponent },
    { path: 'add-vista', component: VistaSsComponent },
    { path: 'edit-vista/:id', component: VistaSsComponent },
    //Entity pivote: RolUsuario
    //Entity pivote: RolVista
    //Login
    { 
        path: 'login', 
        component: LoginComponent 
    },
    { 
        path: 'login/registro', 
        component: RegistroComponent 
    },
    {
        path: '',
        component: HomeComponent
    },
    {
        path: "person",
        component: PersonComponent
    },
    {
        path:"person/registro/:id",
        component: RegistroComponent
    },
    {
        path:'formUsuario',
        component: FormUsuarioComponent
    },
    {
        path: "menu",
        component: MenuComponent
    },
    {
        path:"menu/registro/:id",
        component: RegistroComponent
    },
    //Paths Service Security
    {
        path:"modulo-ss",
        component: ModuloSsComponent
    },
    {
        path: 'rol-ss',
        component: RolSsComponent
    },
    {
        path: 'vista-ss',
        component: VistaSsComponent
    },
    {
        path:'**',
        redirectTo:'',
        pathMatch:'full'
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule {}
