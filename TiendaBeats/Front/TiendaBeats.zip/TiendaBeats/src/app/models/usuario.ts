export interface Usuario{
    id: number;
    nombre: string;
    apellido: string;
    email: string;
    telefono: string;
    username: string;
    password: string;
    fechaNac: number;
}