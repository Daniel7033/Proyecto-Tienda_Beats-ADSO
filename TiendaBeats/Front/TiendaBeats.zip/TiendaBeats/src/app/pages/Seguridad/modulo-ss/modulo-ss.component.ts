import { Component, NgModule, OnInit } from '@angular/core';
import { ModuloService } from '../../../service/modulo.service';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiResponse } from '../../../models/api-response.model';

@Component({
  selector: 'app-modulo-ss',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './modulo-ss.component.html',
  styleUrl: './modulo-ss.component.css'
})
export class ModuloSsComponent implements OnInit {
  modules: any[] = [];
  modulo: any = { id: 0, nombre: '', descripcion: '' };
  isEditMode: boolean = false;

  constructor(private moduloService: ModuloService, private route: ActivatedRoute, private router: Router) { }


  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEditMode = true;
      this.moduloService.getfindById(Number(id)).subscribe(data => {
          this.modulo = data;
      });
    }

    this.moduloService.getAll().subscribe((response: ApiResponse<any>) => {
      this.modules = response.data;
    });
  }

  save(){
    if (this.isEditMode) {
      if (this.modulo.id) {
        this.moduloService.update(this.modulo.id, this.modulo).subscribe(() => {
          this.router.navigate(['/modules']);
        });
      } else {
        console.error("indefinido");
        
      }
    } else {
      this.moduloService.save(this.modulo).subscribe(() => {
        this.router.navigate(['/modules']);
      });
    }
  }

  delete(id: number) {
    this.moduloService.delete(id).subscribe(() => {
      this.modules = this.modules.filter(modulo => modulo.id != id);
    });
  }
}

