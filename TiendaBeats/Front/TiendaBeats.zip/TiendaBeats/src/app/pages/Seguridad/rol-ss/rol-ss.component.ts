import { Component, OnInit } from '@angular/core';
import { RolService } from './rol.service';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ApiResponse } from '../../../models/api-response.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-rol-ss',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './rol-ss.component.html',
  styleUrl: './rol-ss.component.css'
})
export class RolSsComponent implements OnInit{
  roles: any[] = []
  rol: any = { nombre: '', descripcion: '' }
  isEditMode: boolean = false;

  constructor(private service: RolService, private route:ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
      const id = this.route.snapshot.paramMap.get('id')

      if (id) {
        this.isEditMode = true;
        this.service.getfindById(Number(id)).subscribe(data => {
          this.rol = data;
        })
      }

      this.service.getAll().subscribe((response: ApiResponse<any>) => {
        this.roles = response.data
      })
    }

    save(){
      if (this.isEditMode) {
        if (this.rol.id) {
          this.service.update(this.rol.id, this.rol).subscribe(() => {
            this.router.navigate(['/roles']);
          })
        } else {
          console.error("error");
          
        }
      } else {
        this.service.save(this.rol).subscribe(() => {
          this.router.navigate(['/roles']);
        })
      }
    }

    delete(id: number){
      this.service.delete(id).subscribe(() => {
        this.roles = this.roles.filter(rol => rol.id != id)
      })
    }
}
