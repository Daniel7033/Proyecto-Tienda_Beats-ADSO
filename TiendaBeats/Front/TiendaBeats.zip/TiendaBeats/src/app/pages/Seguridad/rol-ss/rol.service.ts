import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiResponse } from '../../../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class RolService {

  private url = 'http://localhost:7033/tiendabeats/roles';

  constructor(private http:HttpClient) { }

  getAll(): Observable<ApiResponse<any>>{
    return this.http.get<ApiResponse<any>>(`${this.url}`);
  }

  getfindById(id: number): Observable<any>{
    return this.http.get<any>(`${this.url}/${id}`)
  }

  save(rol: Object): Observable<Object>{
    return this.http.post(`${this.url}`, rol)
  }

  update(id: number, rol: Object): Observable<Object>{
    return this.http.put(`${this.url}/${id}`, rol)
  }

  delete(id: number): Observable<any>{
    return this.http.delete(`${this.url}/${id}`)
  }
}
