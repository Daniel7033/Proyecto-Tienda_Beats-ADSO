import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { VistaService } from './vista.service';
import { ApiResponse } from '../../../models/api-response.model';

@Component({
  selector: 'app-vista-ss',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './vista-ss.component.html',
  styleUrl: './vista-ss.component.css'
})
export class VistaSsComponent implements OnInit{
  vistas: any[] = []
  vista: any = { nombre: '', descripcion:'', ruta: '' }
  isEditMode: boolean = false

  constructor(private service: VistaService, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEditMode = true;
      this.service.getfindById(Number(id)).subscribe(data => {
          this.vista = data;
      });
    }

    this.service.getAll().subscribe((response: ApiResponse<any>) => {
      this.vistas = response.data;
    });
  }

  save(){
    if (this.isEditMode) {
      if (this.vista.id) {
        this.service.update(this.vista.id, this.vista).subscribe(() => {
          this.router.navigate(['/vistas']);
        });
      } else {
        console.error("indefinido");
        
      }
    } else {
      this.service.save(this.vista).subscribe(() => {
        this.router.navigate(['/vistas']);
      });
    }
  }

  delete(id: number) {
    this.service.delete(id).subscribe(() => {
      this.vistas = this.vistas.filter(vista => vista.id != id);
    });
  }
}
