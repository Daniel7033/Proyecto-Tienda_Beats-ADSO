import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiResponse } from '../../../models/api-response.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VistaService {
  private url = 'http://localhost:7033/tiendabeats/vistas'

  constructor(private http:HttpClient) { }

  getAll(): Observable<ApiResponse<any>>{
    return this.http.get<ApiResponse<any>>(`${this.url}`)
  }

  getfindById(id: number): Observable<any>{
    return this.http.get<any>(`${this.url}/${id}`)
  }

  save(vista: Object): Observable<Object>{
    return this.http.post(`${this.url}`, vista)
  }

  update(id: number, vista: Object): Observable<Object>{
    return this.http.put(`${this.url}/${id}`, vista)
  }

  delete(id: number): Observable<any>{
    return this.http.delete(`${this.url}/${id}`)
  }
}
