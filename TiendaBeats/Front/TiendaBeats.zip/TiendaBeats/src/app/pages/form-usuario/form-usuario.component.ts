import { Component } from '@angular/core';

@Component({
  selector: 'app-form-usuario',
  standalone: true,
  imports: [],
  templateUrl: './form-usuario.component.html',
  styleUrl: './form-usuario.component.css'
})
export class FormUsuarioComponent {

}
