import { CommonModule } from '@angular/common';
import { Component, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent{
  
  constructor(private service: LoginService, private route: ActivatedRoute, private router: Router){}

  signUp(form:any){
    const { username, password } = form.value;
    this.service.login(username, password).subscribe(response => { 
      this.router.navigate(['/menu']);
    });
  }
}
