import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private url = "http://localhost:7033/tiendabeats/usuario/login";

  constructor(private http: HttpClient) { }

  login(username: string, password: string): Observable<any>{
    const body = { username, password };
    return this.http.post(`${this.url}`, body, { observe: 'response'});
  }
}
