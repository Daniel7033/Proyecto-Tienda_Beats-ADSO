import { Component, OnInit } from '@angular/core';
import { ModuloService } from '../../service/modulo.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-modulo-ss',
  standalone: true,
  imports: [ModuloService, ActivatedRoute, Router],
  templateUrl: './modulo-ss.component.html',
  styleUrl: './modulo-ss.component.css'
})
export class ModuloSsComponent implements OnInit {
  modules: any[] = [];
  modulo: any = { nombre: '', descripcion: '' };
  isEditMode: boolean = false;

  constructor(private moduloService: ModuloService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEditMode = true;
      this.moduloService.getfindById(Number(id)).subscribe(data => {
        this.modulo = data;
      });
    }

    this.moduloService.getAll().subscribe(data => {
      this.modules = data;
    });
  }

  save(){
    if (this.isEditMode) {
      this.moduloService.update(this.modulo.id, this.modulo).subscribe(() => {
        this.router.navigate(['/modulo']);
      });
    } else {
      this.moduloService.save(this.modulo).subscribe(() => {
        this.router.navigate(['/modulo']);
      });
    }
  }

  delete(id: number) {
    this.moduloService.delete(id).subscribe(() => {
      this.modules = this.modules.filter(modulo => modulo.id != id);
    });
  }
}

