import { Component, OnInit } from '@angular/core';
import { Usuario } from '../../models/usuario';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-person',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './person.component.html',
  styleUrl: './person.component.css'
})
export class PersonComponent{
}
