import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { UsuarioService } from '../../services/usuario.service';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, RouterModule],
  templateUrl: './registro.component.html',
  styleUrl: './registro.component.css'
})
export class RegistroComponent implements OnInit{
  usuario!:FormGroup;
  saveProgress: boolean = false;
  edit:boolean = false;

  constructor(
    private fb:FormBuilder, 
    private usuarioService:UsuarioService, 
    private activatedRoute:ActivatedRoute,
    private router:Router
  )
  {
    this.usuario = this.fb.group({
      id: [null],
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  ngOnInit(): void{
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != 'new') {
      this.edit = true;
      this.findById(+id!)
    }
  } 

  findById(id:number){
    this.usuarioService.getFingById(id).subscribe({
      next:(foundUsuario)=>{
        this.usuario.patchValue(foundUsuario);
      },
      error:()=>{
        console.error("Dato no encontrado");
        this.router.navigateByUrl('/')
      }
    });
  }

  save(){
      if (this.usuario.invalid) {
        console.error("ERROR");
        return;
      }
      this.usuarioService.save(this.usuario.value).subscribe({
        next:()=>{
          console.log("guardado con exito");
          this.router.navigateByUrl('/')
        },
        error:()=>{
          console.error("ERROR");
          
        }
      });
  }

  update(){
    if (this.usuario.invalid) {
      console.error("ERROR");
      return;
    }
    this.usuarioService.update(this.usuario.value).subscribe({
      next:()=> {
          console.log("actualizado con exito");
          this.router.navigateByUrl('/')
      },
      error:()=> {
          console.error('ERROR');
          
      },
    });
  }
}
