import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ModuloService {

  private url = '';

  constructor(private http: HttpClient) { }

  getAll(): Observable<any>{
    return this.http.get(`${this.url}`)
  }

  getfindById(id: number): Observable<any>{
    return this.http.get(`${this.url}/${id}`)
  }

  save(modulo: Object): Observable<Object>{
    return this.http.post(`${this.url}`, modulo);
  }

  update(id: number, modulo: Object): Observable<Object>{
    return this.http.put(`${this.url}/${id}`, modulo);
  }

  delete(id: number): Observable<any>{
    return this.http.delete(`${this.url}/${id}`);
  }
}
