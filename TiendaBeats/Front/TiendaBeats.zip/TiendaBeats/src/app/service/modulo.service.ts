import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiResponse } from '../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class ModuloService {

  private url = 'http://localhost:7033/tiendabeats/modulo';

  constructor(private http: HttpClient) { }

  getAll(): Observable<ApiResponse<any>>{
    return this.http.get<ApiResponse<any>>(`${this.url}`)
  }

  getfindById(id: number): Observable<any>{
    return this.http.get<any>(`${this.url}/${id}`)
  }

  save(modulo: Object): Observable<Object>{
    return this.http.post(`${this.url}`, modulo);
  }

  update(id: number, modulo: Object): Observable<Object>{
    return this.http.put(`${this.url}/${id}`, modulo);
  }

  delete(id: number): Observable<any>{
    return this.http.delete(`${this.url}/${id}`);
  }
}
